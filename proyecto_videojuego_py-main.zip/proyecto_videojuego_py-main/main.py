import tkinter as tk
from vista.menu_principal import MenuPrincipal  

if __name__ == "__main__":
    root = tk.Tk()
    app = MenuPrincipal(root)
    root.mainloop()
